#ifndef _MOBILE_VIT
#define _MOBILE_VIT

#ifdef __cplusplus
extern "C" {
#endif

// For integration into menu system
void mobileViT_xxs_menu();

#ifdef __cplusplus
}
#endif

#endif 